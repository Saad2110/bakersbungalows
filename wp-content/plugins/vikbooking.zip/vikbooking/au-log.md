### VikBooking Automatic Update | 2021-11-10 20:32:35

```json
{
    "core": [
        {
            "item": {
                "response": "autoupdate",
                "download": "https:\/\/downloads.wordpress.org\/release\/wordpress-5.8.2.zip",
                "locale": "en_US",
                "packages": {
                    "full": "https:\/\/downloads.wordpress.org\/release\/wordpress-5.8.2.zip",
                    "no_content": "https:\/\/downloads.wordpress.org\/release\/wordpress-5.8.2-no-content.zip",
                    "new_bundled": "https:\/\/downloads.wordpress.org\/release\/wordpress-5.8.2-new-bundled.zip",
                    "partial": "https:\/\/downloads.wordpress.org\/release\/wordpress-5.8.2-partial-1.zip",
                    "rollback": "https:\/\/downloads.wordpress.org\/release\/wordpress-5.8.2-rollback-1.zip"
                },
                "current": "5.8.2",
                "version": "5.8.2",
                "php_version": "5.6.20",
                "mysql_version": "5.0",
                "new_bundled": "5.6",
                "partial_version": "5.8.1",
                "new_files": ""
            },
            "result": "5.8.2",
            "name": "WordPress 5.8.2",
            "messages": [
                "Updating to WordPress 5.8.2",
                "Downloading update from https:\/\/downloads.wordpress.org\/release\/wordpress-5.8.2-partial-1.zip&#8230;",
                "The authenticity of wordpress-5.8.2-partial-1.zip could not be verified as no signature was found.",
                "Unpacking the update&#8230;",
                "Verifying the unpacked files&#8230;",
                "Preparing to install the latest version&#8230;",
                "Enabling Maintenance mode&#8230;",
                "Copying the required files&#8230;",
                "Disabling Maintenance mode&#8230;",
                "Upgrading database&#8230;",
                "WordPress updated successfully."
            ]
        }
    ]
}
```

---

