<?php
/**
 * @package     VikBooking
 * @subpackage  com_vikbooking
 * @author      Alessio Gaggii - e4j - Extensionsforjoomla.com
 * @copyright   Copyright (C) 2018 e4j - Extensionsforjoomla.com. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE
 * @link        https://vikwp.com
 */

defined('ABSPATH') or die('No script kiddies please!');

/**
 * Class handler for admin widget "rooms locked".
 * 
 * @since 	1.4.0
 */
class VikBookingAdminWidgetRoomsLocked extends VikBookingAdminWidget
{
	/**
	 * Class constructor will define the widget name and identifier.
	 */
	public function __construct()
	{
		// call parent constructor
		parent::__construct();

		$this->widgetName = JText::_('VBO_W_ROOMSLOCK_TITLE');
		$this->widgetDescr = JText::_('VBO_W_ROOMSLOCK_DESCR');
		$this->widgetId = basename(__FILE__);
	}

	public function render($data = null)
	{
		$dbo = JFactory::getDbo();
		
		$rooms_locked = array();
		
		// clean up the expired pending records
		$q = "DELETE FROM `#__vikbooking_tmplock` WHERE `until`<" . time() . ";";
		$dbo->setQuery($q);
		$dbo->execute();

		// get all future rooms locked
		$q = "SELECT `lock`.*,`r`.`name`,(SELECT CONCAT_WS(' ',`or`.`t_first_name`,`or`.`t_last_name`) FROM `#__vikbooking_ordersrooms` AS `or` WHERE `lock`.`idorder`=`or`.`idorder` LIMIT 1) AS `nominative` FROM `#__vikbooking_tmplock` AS `lock` LEFT JOIN `#__vikbooking_rooms` `r` ON `lock`.`idroom`=`r`.`id` WHERE `lock`.`until`>".time()." ORDER BY `lock`.`id` DESC;";
		$dbo->setQuery($q);
		$dbo->execute();
		if ($dbo->getNumRows() > 0) {
			$rooms_locked = $dbo->loadAssocList();
		}

		if (!count($rooms_locked)) {
			return;
		}
		?>
		<div class="vbo-admin-widget-wrapper">
			<div class="vbo-admin-widget-head">
				<h4><?php VikBookingIcons::e('lock'); ?> <?php echo JText::_('VBDASHROOMSLOCKED'); ?> <span>(<?php echo count($rooms_locked); ?>)</span></h4>
			</div>
			<div class="vbo-dashboard-rooms-locked table-responsive">
				<table class="table">
					<tr class="vbo-dashboard-rooms-locked-firstrow">
						<td class="center"><?php echo JText::_('VBDASHBOOKINGID'); ?></td>
						<td class="center"><?php echo JText::_('VBDASHROOMNAME'); ?></td>
						<td class="center"><?php echo JText::_('VBCUSTOMERNOMINATIVE'); ?></td>
						<td class="center"><?php echo JText::_('VBDASHLOCKUNTIL'); ?></td>
						<td class="center">&nbsp;</td>
					</tr>
				<?php
				foreach ($rooms_locked as $lock) {
					?>
					<tr class="vbo-dashboard-rooms-locked-rows">
						<td class="center">
							<a href="index.php?option=com_vikbooking&amp;task=editorder&amp;cid[]=<?php echo $lock['idorder']; ?>" class="vbo-bookingid" target="_blank"><?php echo $lock['idorder']; ?></a>
						</td>
						<td class="center"><?php echo $lock['name']; ?></td>
						<td class="center"><?php echo $lock['nominative']; ?></td>
						<td class="center"><?php echo date(str_replace("/", $this->datesep, $this->df).' H:i', $lock['until']); ?></td>
						<td class="center">
							<button type="button" class="btn btn-danger" onclick="if (confirm('<?php echo addslashes(JText::_('VBDELCONFIRM')); ?>')) location.href='index.php?option=com_vikbooking&amp;task=unlockrecords&amp;cid[]=<?php echo $lock['id']; ?>';"><?php echo JText::_('VBDASHUNLOCK'); ?></button>
						</td>
					</tr>
					<?php
				}
				?>
				</table>
			</div>
		</div>
		<?php
	}
}
